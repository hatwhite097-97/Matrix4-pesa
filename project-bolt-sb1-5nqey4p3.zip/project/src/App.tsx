import { useState, useEffect, useRef } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

type View = 'home' | 'admin-login' | 'admin-panel';

export default function App() {
  const [view, setView] = useState<View>('home');

  useEffect(() => {
    const adminSession = sessionStorage.getItem('matrixpesa_admin');
    if (adminSession === 'true') {
      setView('admin-panel');
    }
  }, []);

  if (view === 'admin-panel') {
    return <AdminPanel onLogout={() => {
      sessionStorage.removeItem('matrixpesa_admin');
      setView('home');
    }} />;
  }

  if (view === 'admin-login') {
    return <AdminLogin onLogin={() => setView('admin-panel')} onBack={() => setView('home')} />;
  }

  return <UserDashboard onAdminClick={() => setView('admin-login')} />;
}

// ===== USER DASHBOARD =====
function UserDashboard({ onAdminClick }: { onAdminClick: () => void }) {
  const [userId, setUserId] = useState<string | null>(null);
  const [balance, setBalance] = useState(0);
  const [videosWatched, setVideosWatched] = useState(0);
  const [videos, setVideos] = useState<any[]>([]);
  const [watchedIds, setWatchedIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [showVideo, setShowVideo] = useState(false);
  const [currentVideo, setCurrentVideo] = useState<any>(null);
  const [countdown, setCountdown] = useState(30);
  const [showCaptcha, setShowCaptcha] = useState(false);
  const [captchaQ, setCaptchaQ] = useState({ q: '', a: 0 });
  const [captchaInput, setCaptchaInput] = useState('');
  const [captchaError, setCaptchaError] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [phone, setPhone] = useState('');
  const [network, setNetwork] = useState('');
  const [withdrawError, setWithdrawError] = useState('');
  const [withdrawSuccess, setWithdrawSuccess] = useState('');
  const [minWithdraw] = useState(5000);
  const [reward] = useState(30);
  const [toast, setToast] = useState('');
  const [logs, setLogs] = useState<string[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize user
  useEffect(() => {
    initUser();
    loadVideos();
  }, []);

  // Boot logs
  useEffect(() => {
    const boot = [
      '[INIT] MatrixPesa Security Framework v3.0...',
      '[NET] Checking User IP Address...',
      '[NET] VPN/Proxy Detection: NOT DETECTED (Safe)',
      '[BOT] Automation Bot Check: PASSED',
      '[GEO] Location Verified: Tanzania (TZ)',
      '[SEC] SSL/TLS Encryption: ACTIVE',
      '[SYS] All systems nominal. Platform READY.',
    ];
    boot.forEach((msg, i) => setTimeout(() => addLog(msg), i * 400));
  }, []);

  // Tab focus detection
  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden && showVideo) {
        setIsPaused(true);
        addLog('[SECURITY] Tab hidden — video PAUSED');
      } else if (!document.hidden && showVideo) {
        setIsPaused(false);
        addLog('[SECURITY] Tab visible — video RESUMED');
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, [showVideo]);

  // Countdown timer
  useEffect(() => {
    if (!showVideo || isPaused) return;

    timerRef.current = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          setShowVideo(false);
          setShowCaptcha(true);
          generateCaptcha();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [showVideo, isPaused]);

  async function initUser() {
    let storedId = localStorage.getItem('matrixpesa_user_id');
    if (storedId) {
      const { data } = await supabase.from('users').select('*').eq('id', storedId).single();
      if (data) {
        setUserId(data.id);
        setBalance(Number(data.balance) || 0);
        setVideosWatched(data.videos_watched || 0);
        loadWatchedVideos(data.id);
        setLoading(false);
        return;
      }
    }
    const randomPhone = '0' + Math.floor(600000000 + Math.random() * 300000000);
    const { data } = await supabase.from('users').insert({ phone: randomPhone }).select().single();
    if (data) {
      localStorage.setItem('matrixpesa_user_id', data.id);
      setUserId(data.id);
    }
    setLoading(false);
  }

  async function loadVideos() {
    const { data } = await supabase.from('videos').select('*').eq('is_active', true);
    if (data) setVideos(data);
  }

  async function loadWatchedVideos(uid: string) {
    const { data } = await supabase.from('watched_videos').select('video_id').eq('user_id', uid);
    if (data) setWatchedIds(data.map(w => w.video_id));
  }

  function addLog(msg: string) {
    const ts = new Date().toLocaleTimeString('sw-TZ', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setLogs(prev => [...prev.slice(-15), `[${ts}] ${msg}`]);
  }

  function startVideo(video: any) {
    setCurrentVideo(video);
    setCountdown(video.duration || 30);
    setShowVideo(true);
    setIsPaused(false);
    addLog(`[VIDEO] Started: "${video.title}"`);
  }

  function generateCaptcha() {
    const pool = [
      { q: 'Tano na nne ni ngapi?', a: 9 },
      { q: 'Sita kasoro moja ni ngapi?', a: 5 },
      { q: 'Mbili mara tatu ni ngapi?', a: 6 },
      { q: 'Kumi kasoro saba ni ngapi?', a: 3 },
      { q: 'Nane na moja ni ngapi?', a: 9 },
      { q: 'Saba na sita ni ngapi?', a: 13 },
      { q: 'Thelathini gawanya tano ni ngapi?', a: 6 },
      { q: 'Arobaini kasoro ishirini ni ngapi?', a: 20 },
    ];
    const pick = pool[Math.floor(Math.random() * pool.length)];
    setCaptchaQ(pick);
    setCaptchaInput('');
    setCaptchaError(false);
  }

  async function verifyCaptcha() {
    if (parseInt(captchaInput) !== captchaQ.a) {
      setCaptchaError(true);
      addLog('[CAPTCHA] FAILED — Payment blocked');
      return;
    }
    setShowCaptcha(false);
    setCaptchaError(false);

    if (!userId || !currentVideo) return;

    await supabase.from('watched_videos').insert({
      user_id: userId,
      video_id: currentVideo.id,
      reward_earned: reward
    });

    const newBalance = balance + reward;
    const newWatched = videosWatched + 1;
    await supabase.from('users').update({
      balance: newBalance,
      videos_watched: newWatched,
      total_earned: newBalance
    }).eq('id', userId);

    setBalance(newBalance);
    setVideosWatched(newWatched);
    setWatchedIds(prev => [...prev, currentVideo.id]);
    addLog(`[PAYMENT] +Tsh ${reward} credited`);
    setToast(`Hongera! Umepata Tsh ${reward}.00 — Salio: Tsh ${newBalance.toLocaleString()}`);
    setTimeout(() => setToast(''), 4000);
  }

  async function submitWithdraw() {
    setWithdrawError('');
    setWithdrawSuccess('');

    if (balance < minWithdraw) {
      setWithdrawError(`Salio lako (Tsh ${balance.toLocaleString()}) halifiki kiwango cha Tsh ${minWithdraw.toLocaleString()}`);
      return;
    }
    if (!network) {
      setWithdrawError('Chagua mtandao wako');
      return;
    }
    if (phone.length < 9) {
      setWithdrawError('Weka namba sahihi ya simu');
      return;
    }

    await supabase.from('withdrawals').insert({
      user_id: userId,
      amount: balance,
      network,
      phone,
      status: 'pending'
    });

    await supabase.from('users').update({
      balance: 0,
      total_withdrawn: balance
    }).eq('id', userId);

    setWithdrawSuccess(`Ombi la Tsh ${balance.toLocaleString()} kwenda ${network} (${phone}) limepokelewa!`);
    addLog(`[WITHDRAW] Request: Tsh ${balance} → ${network} ${phone}`);
    setBalance(0);
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-matrix-bg">
        <div className="text-matrix-neon font-display text-2xl animate-pulse-glow">MatrixPesa</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-matrix-bg relative">
      <MatrixRain />

      <div className="relative z-10 max-w-4xl mx-auto px-4 pb-20">
        {/* Navbar */}
        <nav className="sticky top-0 z-50 flex items-center justify-between py-4 border-b border-matrix-border bg-matrix-bg/90 backdrop-blur-sm">
          <div className="font-display text-xl font-bold text-matrix-neon">
            Matrix<span className="text-matrix-gold">Pesa</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowWithdraw(true)}
              className="flex flex-col items-end bg-gradient-to-br from-matrix-card to-matrix-surface border border-matrix-neon rounded-xl px-4 py-2 shadow-neon-sm hover:shadow-neon transition-shadow"
            >
              <span className="font-mono text-[10px] text-matrix-muted uppercase tracking-wider">Salio Lako</span>
              <span className="font-display text-lg font-bold text-matrix-gold">Tsh {balance.toLocaleString()}</span>
            </button>
            <button
              onClick={onAdminClick}
              className="text-matrix-muted hover:text-matrix-neon transition-colors font-mono text-sm"
            >
              Admin
            </button>
          </div>
        </nav>

        {/* Trust Banner */}
        <div className="my-6 bg-gradient-to-br from-matrix-surface to-matrix-card border border-matrix-neon rounded-2xl p-6 relative overflow-hidden shadow-neon-sm animate-fade-down">
          <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-matrix-neon to-transparent animate-shimmer" />
          <h2 className="font-display text-lg font-bold text-matrix-gold mb-2">
            KWANINI TUNAKULIPA? (HUU SIO UTAPELI!)
          </h2>
          <p className="text-matrix-text/90 leading-relaxed">
            Sisi <span className="text-matrix-neon font-semibold">hatuombi kiingilio</span> wala hatutaki hela yako.
            Makampuni ya Kitanzania yanatulipa kutangaza — badala ya kula peke wetu,{' '}
            <span className="text-matrix-neon font-semibold">tunagawana nawe</span>. Kila mtu anashinda!
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          {[
            { val: videosWatched, label: 'Video Zilizotazamwa' },
            { val: `Tsh ${reward}`, label: 'Kwa Kila Video' },
            { val: `Tsh ${minWithdraw.toLocaleString()}`, label: 'Kiwango cha Kutoa' },
          ].map((s, i) => (
            <div key={i} className="bg-matrix-card border border-matrix-border rounded-xl p-4 text-center animate-fade-up" style={{ animationDelay: `${i * 0.1}s` }}>
              <div className="font-display text-xl font-bold text-matrix-neon">{s.val}</div>
              <div className="font-mono text-[10px] text-matrix-muted mt-1 uppercase tracking-wider">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Video Tasks */}
        <h3 className="font-display text-lg font-bold text-matrix-neon mb-4 flex items-center gap-3">
          MATANGAZO YANAYOPATIKANA
          <span className="flex-1 h-px bg-gradient-to-r from-matrix-neon to-transparent opacity-40" />
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {videos.map((video, i) => {
            const watched = watchedIds.includes(video.id);
            return (
              <div
                key={video.id}
                className={`bg-matrix-card border rounded-2xl p-5 relative overflow-hidden transition-all duration-300 animate-fade-up ${
                  watched ? 'border-matrix-gold/50 opacity-60' : 'border-matrix-border hover:border-matrix-neon hover:shadow-neon-sm hover:-translate-y-1'
                }`}
                style={{ animationDelay: `${i * 0.08}s` }}
              >
                <div className="absolute top-3 right-3 bg-gradient-gold text-black font-display text-xs font-bold px-3 py-1 rounded-full shadow-gold-sm">
                  +Tsh {video.reward || reward}
                </div>
                <div className="font-mono text-[10px] text-matrix-neon/70 uppercase tracking-wider mb-2">
                  {video.advertiser}
                </div>
                <h4 className="font-body text-lg font-semibold text-matrix-text mb-3 pr-16">{video.title}</h4>
                <div className="flex gap-2 mb-4">
                  <span className="font-mono text-xs bg-matrix-neon/10 border border-matrix-neon/20 text-matrix-neon px-2 py-1 rounded-md">
                    {video.duration || 30}s
                  </span>
                  <span className="font-mono text-xs bg-matrix-neon/10 border border-matrix-neon/20 text-matrix-neon px-2 py-1 rounded-md">
                    Inalindwa
                  </span>
                </div>
                <button
                  disabled={watched}
                  onClick={() => startVideo(video)}
                  className={`w-full py-3 rounded-xl font-display font-bold tracking-wider transition-all ${
                    watched
                      ? 'bg-matrix-border text-matrix-muted cursor-not-allowed'
                      : 'bg-gradient-matrix border border-matrix-neon text-matrix-neon shadow-neon-sm hover:shadow-neon'
                  }`}
                >
                  {watched ? '✓ Umetazama' : '▶ TAZAMA VIDEO'}
                </button>
                {watched && <div className="text-center font-mono text-xs text-matrix-gold mt-2">Umeshapata Malipo</div>}
              </div>
            );
          })}
        </div>

        {/* Console */}
        <div className="mt-8 bg-black border border-matrix-border rounded-xl p-4 font-mono text-xs text-matrix-neon/80 leading-relaxed overflow-hidden max-h-48">
          <div className="border-b border-matrix-border pb-2 mb-2 font-bold text-matrix-neon tracking-wider">
            MATRIXPESA // SECURITY CONSOLE v3.0
          </div>
          {logs.map((log, i) => (
            <div key={i} className={log.includes('FAILED') || log.includes('PAUSED') ? 'text-red-400' : log.includes('PAYMENT') || log.includes('READY') ? 'text-green-400' : 'text-matrix-muted'}>
              {log}
            </div>
          ))}
          <span className="inline-block w-2 h-4 bg-matrix-neon animate-blink ml-1" />
        </div>

        {/* Footer */}
        <footer className="mt-8 text-center font-mono text-xs text-matrix-muted border-t border-matrix-border pt-4">
          MatrixPesa © 2026 · Jukwaa la Kitanzania
          <br />
          Kutoa pesa kunahitaji angalau Tsh {minWithdraw.toLocaleString()} · support@matrixpesa.co.tz
        </footer>
      </div>

      {/* Modals */}
      <VideoModal show={showVideo} video={currentVideo} countdown={countdown} isPaused={isPaused} onClose={() => setShowVideo(false)} />
      <CaptchaModal show={showCaptcha} captchaQ={captchaQ} captchaInput={captchaInput} setCaptchaInput={setCaptchaInput} captchaError={captchaError} onVerify={verifyCaptcha} onClose={() => setShowCaptcha(false)} />
      <WithdrawModal show={showWithdraw} balance={balance} network={network} setNetwork={setNetwork} phone={phone} setPhone={setPhone} withdrawError={withdrawError} withdrawSuccess={withdrawSuccess} onSubmit={submitWithdraw} onClose={() => setShowWithdraw(false)} />

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 bg-gradient-matrix border border-matrix-neon rounded-full px-6 py-3 font-display text-matrix-neon shadow-neon animate-pop-in z-50">
          {toast}
        </div>
      )}
    </div>
  );
}

// ===== VIDEO MODAL =====
function VideoModal({ show, video, countdown, isPaused, onClose }: { show: boolean; video: any; countdown: number; isPaused: boolean; onClose: () => void }) {
  if (!show) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-md bg-matrix-surface border border-matrix-neon rounded-2xl p-6 shadow-neon-lg animate-pop-in" onClick={e => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-4 right-4 text-matrix-muted hover:text-red-400 font-mono text-xl">✕</button>

        <div className="text-center">
          <h3 className="font-display text-xl font-bold text-matrix-neon mb-1">{video?.title}</h3>
          <p className="font-mono text-xs text-matrix-muted mb-6">{video?.advertiser}</p>

          {isPaused && (
            <div className="mb-4 bg-red-500/10 border border-red-500 rounded-xl p-4 animate-blink">
              <p className="font-display text-red-500">⏸ IMESIMAMISHWA</p>
              <p className="text-xs text-red-400 mt-1">Rudi kwenye tab hii</p>
            </div>
          )}

          <div className="bg-black border border-matrix-border rounded-xl aspect-video flex items-center justify-center mb-4 relative overflow-hidden">
            <div className="text-6xl animate-pulse-glow">📺</div>
            <div className="absolute bottom-2 font-mono text-xs text-matrix-muted">{video?.advertiser}</div>
          </div>

          <div className="mb-4">
            <div className="flex justify-between font-mono text-xs text-matrix-muted mb-2">
              <span>Maendeleo</span>
              <span>{Math.round(((video?.duration || 30) - countdown) / (video?.duration || 30) * 100)}%</span>
            </div>
            <div className="h-2 bg-matrix-border rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-matrix-neon to-matrix-gold rounded-full transition-all duration-1000"
                style={{ width: `${((video?.duration || 30) - countdown) / (video?.duration || 30) * 100}%` }}
              />
            </div>
          </div>

          <div className="font-display text-4xl font-bold text-matrix-neon animate-count-pulse">
            {countdown}<span className="text-lg">s</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ===== CAPTCHA MODAL =====
function CaptchaModal({ show, captchaQ, captchaInput, setCaptchaInput, captchaError, onVerify, onClose }: { show: boolean; captchaQ: { q: string; a: number }; captchaInput: string; setCaptchaInput: (v: string) => void; captchaError: boolean; onVerify: () => void; onClose: () => void }) {
  if (!show) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-md bg-matrix-surface border border-matrix-neon rounded-2xl p-6 shadow-neon-lg animate-pop-in" onClick={e => e.stopPropagation()}>
        <div className="text-center">
          <h3 className="font-display text-xl font-bold text-matrix-neon mb-1">Thibitisha Wewe ni Binadamu</h3>
          <p className="font-mono text-xs text-matrix-muted mb-6">Jibu swali kupata malipo</p>

          <p className="font-display text-2xl font-bold text-matrix-gold my-6">{captchaQ.q}</p>

          <input
            type="number"
            value={captchaInput}
            onChange={(e) => setCaptchaInput(e.target.value)}
            className="w-full bg-matrix-card border border-matrix-neon rounded-xl px-4 py-3 text-center font-display text-2xl text-matrix-text focus:outline-none focus:shadow-neon mb-4"
            placeholder="Jibu..."
            autoFocus
          />

          {captchaError && (
            <div className="bg-red-500/10 border border-red-500 rounded-xl p-3 mb-4 text-red-400 font-mono text-sm">
              Jibu Si Sahihi! Umeshindwa kupata malipo.
            </div>
          )}

          <button
            onClick={onVerify}
            className="w-full py-3 bg-gradient-to-r from-matrix-neon to-matrix-neonDim text-black font-display font-bold rounded-xl hover:shadow-neon transition-shadow"
          >
            ✅ THIBITISHA NA POKEA PESA
          </button>
        </div>
      </div>
    </div>
  );
}

// ===== WITHDRAW MODAL =====
function WithdrawModal({ show, balance, network, setNetwork, phone, setPhone, withdrawError, withdrawSuccess, onSubmit, onClose }: { show: boolean; balance: number; network: string; setNetwork: (v: string) => void; phone: string; setPhone: (v: string) => void; withdrawError: string; withdrawSuccess: string; onSubmit: () => void; onClose: () => void }) {
  if (!show) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-md bg-matrix-surface border border-matrix-neon rounded-2xl p-6 shadow-neon-lg animate-pop-in" onClick={e => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-4 right-4 text-matrix-muted hover:text-red-400 font-mono text-xl">✕</button>

        <h3 className="font-display text-xl font-bold text-matrix-gold mb-1">Toa Pesa</h3>
        <p className="font-mono text-xs text-matrix-muted mb-6">
          Salio: <span className="text-matrix-gold">Tsh {balance.toLocaleString()}</span>
        </p>

        <p className="font-mono text-xs text-matrix-muted uppercase tracking-wider mb-2">Chagua Mtandao</p>
        <div className="grid grid-cols-2 gap-2 mb-6">
          {['M-Pesa', 'TigoPesa', 'AirtelMoney', 'HaloPesa'].map((net) => (
            <button
              key={net}
              onClick={() => setNetwork(net)}
              className={`py-3 rounded-xl font-display font-semibold transition-all ${
                network === net
                  ? 'bg-matrix-gold/20 border border-matrix-gold text-matrix-gold shadow-gold-sm'
                  : 'bg-matrix-card border border-matrix-border text-matrix-text hover:border-matrix-neon'
              }`}
            >
              {net}
            </button>
          ))}
        </div>

        <p className="font-mono text-xs text-matrix-muted uppercase tracking-wider mb-2">Namba ya Simu</p>
        <input
          type="tel"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          className="w-full bg-matrix-card border border-matrix-border rounded-xl px-4 py-3 font-mono text-lg text-matrix-text focus:outline-none focus:border-matrix-neon mb-4"
          placeholder="0712 345 678"
          maxLength={10}
        />

        {withdrawError && (
          <div className="bg-red-500/10 border border-red-500 rounded-xl p-3 mb-4 text-red-400 font-mono text-sm">
            ❌ {withdrawError}
          </div>
        )}

        {withdrawSuccess && (
          <div className="bg-matrix-neon/10 border border-matrix-neon rounded-xl p-3 mb-4 text-matrix-neon font-mono text-sm">
            ✅ {withdrawSuccess}
          </div>
        )}

        <button
          onClick={onSubmit}
          className="w-full py-3 bg-gradient-gold text-black font-display font-bold rounded-xl hover:shadow-gold transition-shadow"
        >
          🏧 OMBA KUTOA PESA
        </button>
      </div>
    </div>
  );
}

// ===== ADMIN LOGIN =====
function AdminLogin({ onLogin, onBack }: { onLogin: () => void; onBack: () => void }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleLogin() {
    setLoading(true);
    setError('');

    const { data } = await supabase.from('settings').select('value').eq('key', 'admin_password').single();
    const correctPassword = data?.value || 'matrix2024';

    if (password === correctPassword) {
      sessionStorage.setItem('matrixpesa_admin', 'true');
      setLoading(false);
      onLogin();
    } else {
      setLoading(false);
      setError('Password sio sahihi');
    }
  }

  return (
    <div className="min-h-screen bg-matrix-bg flex items-center justify-center p-4">
      <MatrixRain />
      <div className="relative z-10 w-full max-w-md bg-matrix-surface border border-matrix-neon rounded-2xl p-8 shadow-neon animate-pop-in">
        <button onClick={onBack} className="text-matrix-muted hover:text-matrix-neon font-mono text-sm mb-6">
          ← Rudi Nyumbani
        </button>

        <h1 className="font-display text-2xl font-bold text-matrix-neon mb-2">Admin Login</h1>
        <p className="font-mono text-xs text-matrix-muted mb-6">Ingia kwenye panel ya usimamizi</p>

        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
          className="w-full bg-matrix-card border border-matrix-neon rounded-xl px-4 py-4 font-mono text-lg text-matrix-text focus:outline-none focus:shadow-neon mb-4"
          placeholder="Password..."
          autoFocus
        />

        {error && (
          <div className="bg-red-500/10 border border-red-500 rounded-xl p-3 mb-4 text-red-400 font-mono text-sm text-center">
            {error}
          </div>
        )}

        <button
          onClick={handleLogin}
          disabled={loading}
          className="w-full py-4 bg-gradient-to-r from-matrix-neon to-matrix-neonDim text-black font-display font-bold rounded-xl hover:shadow-neon transition-shadow disabled:opacity-50"
        >
          {loading ? 'Inachunguza...' : 'INGIA'}
        </button>
      </div>
    </div>
  );
}

// ===== ADMIN PANEL =====
function AdminPanel({ onLogout }: { onLogout: () => void }) {
  const [tab, setTab] = useState<'overview' | 'users' | 'videos' | 'withdrawals'>('overview');
  const [stats, setStats] = useState({ users: 0, videos: 0, withdrawals: 0, pendingWithdrawals: 0, totalPaid: 0 });
  const [users, setUsers] = useState<any[]>([]);
  const [allVideos, setAllVideos] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    const [usersRes, videosRes, withdrawalsRes] = await Promise.all([
      supabase.from('users').select('*').order('created_at', { ascending: false }).limit(50),
      supabase.from('videos').select('*').order('created_at', { ascending: false }),
      supabase.from('withdrawals').select('*, users(phone)').order('created_at', { ascending: false }).limit(50),
    ]);

    if (usersRes.data) {
      setUsers(usersRes.data);
      setStats(s => ({
        ...s,
        users: usersRes.data.length,
        totalPaid: usersRes.data.reduce((sum, u) => sum + Number(u.total_withdrawn || 0), 0)
      }));
    }
    if (videosRes.data) {
      setAllVideos(videosRes.data);
      setStats(s => ({ ...s, videos: videosRes.data.length }));
    }
    if (withdrawalsRes.data) {
      setWithdrawals(withdrawalsRes.data);
      setStats(s => ({
        ...s,
        withdrawals: withdrawalsRes.data.length,
        pendingWithdrawals: withdrawalsRes.data.filter(w => w.status === 'pending').length
      }));
    }
    setLoading(false);
  }

  async function approveWithdrawal(id: string) {
    await supabase.from('withdrawals').update({ status: 'approved', processed_at: new Date().toISOString() }).eq('id', id);
    loadData();
  }

  async function rejectWithdrawal(id: string) {
    await supabase.from('withdrawals').update({ status: 'rejected', processed_at: new Date().toISOString() }).eq('id', id);
    loadData();
  }

  async function toggleVideo(id: string, isActive: boolean) {
    await supabase.from('videos').update({ is_active: !isActive }).eq('id', id);
    loadData();
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-matrix-bg flex items-center justify-center">
        <div className="text-matrix-neon font-display text-2xl animate-pulse-glow">Admin Panel...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-matrix-bg">
      <MatrixRain />

      <div className="relative z-10">
        {/* Admin Header */}
        <header className="sticky top-0 z-50 bg-matrix-bg/95 backdrop-blur border-b border-matrix-border">
          <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
            <div>
              <h1 className="font-display text-xl font-bold text-matrix-neon">Admin Panel</h1>
              <p className="font-mono text-xs text-matrix-muted">MatrixPesa Management</p>
            </div>
            <button onClick={onLogout} className="font-mono text-sm text-matrix-muted hover:text-red-400 transition-colors">
              Logout
            </button>
          </div>

          {/* Tabs */}
          <div className="max-w-6xl mx-auto px-4 flex gap-2 pb-4">
            {(['overview', 'users', 'videos', 'withdrawals'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`px-4 py-2 rounded-lg font-display font-semibold text-sm transition-all ${
                  tab === t
                    ? 'bg-matrix-neon/20 border border-matrix-neon text-matrix-neon'
                    : 'bg-matrix-card border border-matrix-border text-matrix-muted hover:border-matrix-neon/50'
                }`}
              >
                {t.charAt(0).toUpperCase() + t.slice(1)}
              </button>
            ))}
          </div>
        </header>

        <main className="max-w-6xl mx-auto px-4 py-6">
          {/* Overview Tab */}
          {tab === 'overview' && (
            <div className="animate-fade-up">
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
                {[
                  { label: 'Watumiaji', val: stats.users, color: 'neon' },
                  { label: 'Video', val: stats.videos, color: 'neon' },
                  { label: 'Maombi', val: stats.withdrawals, color: 'gold' },
                  { label: 'Yanasubiri', val: stats.pendingWithdrawals, color: 'gold' },
                  { label: 'Yametumwa', val: `Tsh ${stats.totalPaid.toLocaleString()}`, color: 'neon' },
                ].map((s, i) => (
                  <div key={i} className="bg-matrix-card border border-matrix-border rounded-xl p-4">
                    <div className={`font-display text-xl font-bold text-matrix-${s.color}`}>{s.val}</div>
                    <div className="font-mono text-xs text-matrix-muted uppercase tracking-wider mt-1">{s.label}</div>
                  </div>
                ))}
              </div>

              <div className="bg-matrix-card border border-matrix-border rounded-xl p-6">
                <h3 className="font-display text-lg font-bold text-matrix-neon mb-4">Karibu Admin Panel</h3>
                <p className="text-matrix-muted leading-relaxed">
                  Hapa unaweza kuona takwimu, kusimamia matangazo, kuidhinisha maombi ya kutoa pesa, na kuangalia watumiaji.
                </p>
              </div>
            </div>
          )}

          {/* Users Tab */}
          {tab === 'users' && (
            <div className="animate-fade-up">
              <div className="bg-matrix-card border border-matrix-border rounded-xl overflow-hidden overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-matrix-surface">
                    <tr>
                      <th className="px-4 py-3 text-left font-mono text-xs text-matrix-muted uppercase">Phone</th>
                      <th className="px-4 py-3 text-left font-mono text-xs text-matrix-muted uppercase">Salio</th>
                      <th className="px-4 py-3 text-left font-mono text-xs text-matrix-muted uppercase">Video</th>
                      <th className="px-4 py-3 text-left font-mono text-xs text-matrix-muted uppercase">Alipwa</th>
                      <th className="px-4 py-3 text-left font-mono text-xs text-matrix-muted uppercase">Tarehe</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((u) => (
                      <tr key={u.id} className="border-t border-matrix-border hover:bg-matrix-surface/50">
                        <td className="px-4 py-3 font-mono text-sm text-matrix-text">{u.phone}</td>
                        <td className="px-4 py-3 font-display text-sm text-matrix-gold">Tsh {Number(u.balance).toLocaleString()}</td>
                        <td className="px-4 py-3 font-mono text-sm text-matrix-neon">{u.videos_watched}</td>
                        <td className="px-4 py-3 font-mono text-sm text-matrix-text">Tsh {Number(u.total_withdrawn || 0).toLocaleString()}</td>
                        <td className="px-4 py-3 font-mono text-xs text-matrix-muted">{new Date(u.created_at).toLocaleDateString('sw-TZ')}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Videos Tab */}
          {tab === 'videos' && (
            <div className="animate-fade-up">
              <div className="grid gap-4">
                {allVideos.map((v) => (
                  <div key={v.id} className={`bg-matrix-card border rounded-xl p-4 flex items-center justify-between ${v.is_active ? 'border-matrix-border' : 'border-red-500/30 opacity-60'}`}>
                    <div>
                      <div className="font-mono text-xs text-matrix-neon/70 uppercase mb-1">{v.advertiser}</div>
                      <div className="font-body font-semibold text-matrix-text">{v.title}</div>
                      <div className="font-mono text-xs text-matrix-muted mt-1">
                        Tsh {v.reward} · {v.views_count || 0} views · {v.duration}s
                      </div>
                    </div>
                    <button
                      onClick={() => toggleVideo(v.id, v.is_active)}
                      className={`px-4 py-2 rounded-lg font-display font-semibold text-sm ${
                        v.is_active
                          ? 'bg-red-500/20 border border-red-500 text-red-400 hover:bg-red-500/30'
                          : 'bg-matrix-neon/20 border border-matrix-neon text-matrix-neon hover:bg-matrix-neon/30'
                      }`}
                    >
                      {v.is_active ? 'Zima' : 'Washa'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Withdrawals Tab */}
          {tab === 'withdrawals' && (
            <div className="animate-fade-up">
              <div className="bg-matrix-card border border-matrix-border rounded-xl overflow-hidden overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-matrix-surface">
                    <tr>
                      <th className="px-4 py-3 text-left font-mono text-xs text-matrix-muted uppercase">Kiasi</th>
                      <th className="px-4 py-3 text-left font-mono text-xs text-matrix-muted uppercase">Mtandao</th>
                      <th className="px-4 py-3 text-left font-mono text-xs text-matrix-muted uppercase">Simu</th>
                      <th className="px-4 py-3 text-left font-mono text-xs text-matrix-muted uppercase">Hali</th>
                      <th className="px-4 py-3 text-left font-mono text-xs text-matrix-muted uppercase">Tarehe</th>
                      <th className="px-4 py-3 text-left font-mono text-xs text-matrix-muted uppercase">Hatua</th>
                    </tr>
                  </thead>
                  <tbody>
                    {withdrawals.map((w) => (
                      <tr key={w.id} className="border-t border-matrix-border hover:bg-matrix-surface/50">
                        <td className="px-4 py-3 font-display text-sm text-matrix-gold">Tsh {Number(w.amount).toLocaleString()}</td>
                        <td className="px-4 py-3 font-mono text-sm text-matrix-text">{w.network}</td>
                        <td className="px-4 py-3 font-mono text-sm text-matrix-text">{w.phone}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-full font-mono text-xs ${
                            w.status === 'approved' ? 'bg-green-500/20 text-green-400' :
                            w.status === 'rejected' ? 'bg-red-500/20 text-red-400' :
                            'bg-yellow-500/20 text-yellow-400'
                          }`}>
                            {w.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-mono text-xs text-matrix-muted">{new Date(w.created_at).toLocaleDateString('sw-TZ')}</td>
                        <td className="px-4 py-3">
                          {w.status === 'pending' && (
                            <div className="flex gap-2">
                              <button
                                onClick={() => approveWithdrawal(w.id)}
                                className="px-3 py-1 bg-matrix-neon/20 border border-matrix-neon text-matrix-neon rounded-lg font-display text-xs hover:bg-matrix-neon/30"
                              >
                                ✓
                              </button>
                              <button
                                onClick={() => rejectWithdrawal(w.id)}
                                className="px-3 py-1 bg-red-500/20 border border-red-500 text-red-400 rounded-lg font-display text-xs hover:bg-red-500/30"
                              >
                                ✗
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

// ===== MATRIX RAIN COMPONENT =====
function MatrixRain() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const chars = '01アイウエオカキクケコ田中山川日月火水木金土01MatrixPesa0110';
    let cols: number;
    let drops: number[];
    let animationId: number;

    function resize() {
      if (!canvas) return;
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      cols = Math.floor(canvas.width / 18);
      drops = Array(cols).fill(1);
    }

    function draw() {
      if (!canvas || !ctx) return;
      ctx.fillStyle = 'rgba(5, 10, 5, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#00ff41';
      ctx.font = '14px Share Tech Mono';
      for (let i = 0; i < drops.length; i++) {
        const ch = chars[Math.floor(Math.random() * chars.length)];
        ctx.fillText(ch, i * 18, drops[i] * 18);
        if (drops[i] * 18 > canvas.height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
      }
      animationId = requestAnimationFrame(draw);
    }

    resize();
    window.addEventListener('resize', resize);
    animationId = requestAnimationFrame(draw);

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return <canvas ref={canvasRef} id="matrix-canvas" />;
}
