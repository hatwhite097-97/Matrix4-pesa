/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        matrix: {
          bg: '#050a05',
          surface: '#0b120b',
          card: '#0f1a0f',
          border: '#1a2e1a',
          neon: '#00ff41',
          neonDim: '#00cc33',
          gold: '#ffc107',
          goldDim: '#e6a800',
          text: '#c8ffc8',
          muted: '#4a6e4a',
        },
      },
      fontFamily: {
        display: ['Orbitron', 'sans-serif'],
        mono: ['Share Tech Mono', 'monospace'],
        body: ['Rajdhani', 'sans-serif'],
      },
      animation: {
        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
        'shimmer': 'shimmer 3s linear infinite',
        'fade-up': 'fadeUp 0.5s ease both',
        'fade-down': 'fadeDown 0.6s ease both',
        'pop-in': 'popIn 0.3s cubic-bezier(0.34,1.56,0.64,1) both',
        'blink': 'blink 1s step-end infinite',
        'matrix-rain': 'matrixRain 20s linear infinite',
        'count-pulse': 'countPulse 1s ease-in-out infinite',
      },
      keyframes: {
        pulseGlow: {
          '0%, 100%': { opacity: '1', transform: 'scale(1)' },
          '50%': { opacity: '0.6', transform: 'scale(0.95)' },
        },
        shimmer: {
          from: { transform: 'translateX(-100%)' },
          to: { transform: 'translateX(100%)' },
        },
        fadeUp: {
          from: { opacity: '0', transform: 'translateY(20px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        fadeDown: {
          from: { opacity: '0', transform: 'translateY(-20px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        popIn: {
          from: { opacity: '0', transform: 'scale(0.88)' },
          to: { opacity: '1', transform: 'scale(1)' },
        },
        blink: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.5' },
        },
        countPulse: {
          '0%, 100%': { transform: 'scale(1)' },
          '50%': { transform: 'scale(1.05)' },
        },
      },
      boxShadow: {
        'neon': '0 0 20px rgba(0, 255, 65, 0.3)',
        'neon-sm': '0 0 10px rgba(0, 255, 65, 0.2)',
        'neon-lg': '0 0 40px rgba(0, 255, 65, 0.4)',
        'gold': '0 0 20px rgba(255, 193, 7, 0.3)',
        'gold-sm': '0 0 10px rgba(255, 193, 7, 0.2)',
      },
      backgroundImage: {
        'gradient-matrix': 'linear-gradient(135deg, #003d10, #002d0b)',
        'gradient-gold': 'linear-gradient(135deg, #ffc107, #e6a800)',
        'gradient-neon': 'linear-gradient(90deg, #00ff41, #00cc33)',
      },
    },
  },
  plugins: [],
};
