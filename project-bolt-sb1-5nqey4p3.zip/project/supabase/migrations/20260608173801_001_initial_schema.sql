-- ===== USERS TABLE =====
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone VARCHAR(20) UNIQUE NOT NULL,
  balance DECIMAL(12,2) DEFAULT 0.00,
  videos_watched INTEGER DEFAULT 0,
  total_earned DECIMAL(12,2) DEFAULT 0.00,
  total_withdrawn DECIMAL(12,2) DEFAULT 0.00,
  referral_code VARCHAR(10) UNIQUE DEFAULT upper(substring(md5(random()::text), 1, 6)),
  referred_by UUID REFERENCES users(id),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- ===== VIDEOS/ADS TABLE =====
CREATE TABLE videos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(255) NOT NULL,
  description TEXT,
  advertiser VARCHAR(255) NOT NULL,
  video_url TEXT,
  thumbnail_url TEXT,
  duration INTEGER DEFAULT 30,
  reward DECIMAL(12,2) DEFAULT 30.00,
  is_active BOOLEAN DEFAULT true,
  views_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ===== WATCHED VIDEOS TABLE =====
CREATE TABLE watched_videos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  video_id UUID REFERENCES videos(id) ON DELETE CASCADE,
  reward_earned DECIMAL(12,2) DEFAULT 30.00,
  watched_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, video_id)
);

-- ===== WITHDRAWALS TABLE =====
CREATE TABLE withdrawals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  amount DECIMAL(12,2) NOT NULL,
  network VARCHAR(50) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  status VARCHAR(20) DEFAULT 'pending',
  reference VARCHAR(100),
  processed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ===== ADMINS TABLE =====
CREATE TABLE admins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  is_active BOOLEAN DEFAULT true,
  last_login TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ===== SETTINGS TABLE =====
CREATE TABLE settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key VARCHAR(100) UNIQUE NOT NULL,
  value TEXT NOT NULL,
  description TEXT,
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- ===== ENABLE RLS =====
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE watched_videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE withdrawals ENABLE ROW LEVEL SECURITY;
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

-- ===== RLS POLICIES FOR USERS =====
CREATE POLICY "users_select_own" ON users FOR SELECT
  USING (true);
CREATE POLICY "users_insert_own" ON users FOR INSERT
  WITH CHECK (true);
CREATE POLICY "users_update_own" ON users FOR UPDATE
  USING (true) WITH CHECK (true);

-- ===== RLS POLICIES FOR VIDEOS =====
CREATE POLICY "videos_select_all" ON videos FOR SELECT
  USING (is_active = true);
CREATE POLICY "videos_update_admin" ON videos FOR UPDATE
  USING (true);
CREATE POLICY "videos_insert_admin" ON videos FOR INSERT
  WITH CHECK (true);

-- ===== RLS POLICIES FOR WATCHED VIDEOS =====
CREATE POLICY "watched_select_own" ON watched_videos FOR SELECT
  USING (true);
CREATE POLICY "watched_insert_own" ON watched_videos FOR INSERT
  WITH CHECK (true);

-- ===== RLS POLICIES FOR WITHDRAWALS =====
CREATE POLICY "withdrawals_select_own" ON withdrawals FOR SELECT
  USING (true);
CREATE POLICY "withdrawals_insert_own" ON withdrawals FOR INSERT
  WITH CHECK (true);
CREATE POLICY "withdrawals_update_admin" ON withdrawals FOR UPDATE
  USING (true);

-- ===== RLS POLICIES FOR ADMINS =====
CREATE POLICY "admins_select" ON admins FOR SELECT
  USING (true);
CREATE POLICY "admins_update" ON admins FOR UPDATE
  USING (true);

-- ===== RLS POLICIES FOR SETTINGS =====
CREATE POLICY "settings_select" ON settings FOR SELECT
  USING (true);
CREATE POLICY "settings_update" ON settings FOR UPDATE
  USING (true);

-- ===== INDEXES =====
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_users_referral ON users(referral_code);
CREATE INDEX idx_watched_user_video ON watched_videos(user_id, video_id);
CREATE INDEX idx_withdrawals_user ON withdrawals(user_id);
CREATE INDEX idx_withdrawals_status ON withdrawals(status);

-- ===== INSERT DEFAULT SETTINGS =====
INSERT INTO settings (key, value, description) VALUES
  ('min_withdrawal', '5000', 'Minimum withdrawal amount in TZS'),
  ('reward_per_video', '30', 'Reward per video in TZS'),
  ('site_name', 'MatrixPesa', 'Site name'),
  ('admin_password', 'matrix2024', 'Admin login password');

-- ===== INSERT SAMPLE VIDEOS =====
INSERT INTO videos (title, advertiser, description, duration, reward, is_active) VALUES
  ('Viwanja Kigamboni Smart City — Weka Akiba Yako Leo!', 'Kigamboni Developers Ltd', 'Fursa ya kupata viwanja vya bei nafuu Kigamboni', 30, 30.00, true),
  ('Ofa ya Nguo Shule — Juma Clothing Dar es Salaam', 'Juma Clothing Co.', 'Nguo za kisasa kwa bei nafuu', 30, 30.00, true),
  ('Simu za Bei Nafuu — TechHub Tanzania Dodoma', 'TechHub Tanzania', 'Simu na vifaa vya elektroniki vya bei nafuu', 30, 30.00, true),
  ('Mkopo wa Haraka — Wakoba Microfinance Group', 'Wakoba Finance', 'Mikopo ya haraka kwa wafanyabiashara', 30, 30.00, true),
  ('Bima ya Afya ya Familia — Jubilee Insurance TZ', 'Jubilee Insurance', 'Bima bora ya afya kwa familia yako', 30, 30.00, true),
  ('Vyakula vya Asili — Mama Pima Organic Foods Moshi', 'Mama Pima Foods', 'Vyakula vya asili vya bei nafuu', 30, 30.00, true);
